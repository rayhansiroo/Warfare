// Skydrop deal scanner: fetch real cached fares (Travelpayouts/Aviasales Data API),
// spot drops vs each route's own history, write public/deals.json, send alerts via Resend.
import fs from "node:fs";
import crypto from "node:crypto";
const cfg = JSON.parse(fs.readFileSync(new URL("../config.json", import.meta.url)));
const E = process.env, DRY = !!E.DRY_RUN, MOCK = !!E.MOCK;
const SF = new URL("../data/state.json", import.meta.url), DF = new URL("../public/deals.json", import.meta.url);
const state = fs.existsSync(SF) ? JSON.parse(fs.readFileSync(SF)) : {};
state.routes ||= {}; state.sent ||= {}; state.seg ||= {}; state.cities ||= {};
if (!MOCK && !E.TRAVELPAYOUTS_TOKEN) { console.error("Missing TRAVELPAYOUTS_TOKEN"); process.exit(1); }

const MO = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const med = a => { const s = [...a].sort((x, y) => x - y), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
const dm = a => a.slice(8, 10) + a.slice(5, 7);
const fd = (a, b) => { const x = new Date(a.slice(0, 10)), y = b && new Date(b.slice(0, 10));
  return MO[x.getUTCMonth()] + " " + x.getUTCDate() + (y ? "–" + (y.getUTCMonth() == x.getUTCMonth() ? "" : MO[y.getUTCMonth()] + " ") + y.getUTCDate() : ""); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function j(url, opt) { if (MOCK) return mock(url);
  const r = await fetch(url, opt); if (!r.ok) throw new Error(r.status + " " + url.split("?")[0]); return r.json(); }
const TP = u => j("https://api.travelpayouts.com" + u, { headers: { "X-Access-Token": E.TRAVELPAYOUTS_TOKEN || "" } });
const RS = (p, body, method = "POST") => j("https://api.resend.com" + p, { method,
  headers: { Authorization: "Bearer " + E.RESEND_API_KEY, "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });

// offline fixture for testing the logic without network
let tick = +(E.MOCK_TICK || 0);
function mock(u) {
  if (u.includes("duffel")) return { data: { offers: [{ total_amount: "380.00", total_currency: "USD" }] } };
  if (u.includes("cities.json")) return [{ code: "LIS", name: "Lisbon", country_code: "PT" }, { code: "JFK", name: "New York", country_code: "US" }, { code: "MIA", name: "Miami", country_code: "US" }];
  const f = tick >= 5 ? .5 : 1;
  return { success: true, data: [["LIS", 700], ["MIA", 190]].map(([d, p]) => ({ origin: "JFK", destination: d, price: Math.round(p * f * (1 + (tick % 3) * .02)), transfers: 0, airline: "XX", departure_at: "2026-12-03T10:00:00+00:00", return_at: "2026-12-10T10:00:00+00:00", link: "/search/JFK0312" + d + "10121" })) };
}

async function cities() {
  if (Object.keys(state.cities).length) return;
  try { for (const c of await j("https://api.travelpayouts.com/data/en/cities.json")) state.cities[c.code] = { n: c.name, c: c.country_code }; }
  catch (e) { console.warn("cities.json unavailable:", e.message); }
}
const nm = c => state.cities[c]?.n || c;
async function segId(name) {
  if (state.seg[name]) return state.seg[name];
  const l = await RS("/segments", null, "GET"), f = (l.data || []).find(s => s.name == name);
  return state.seg[name] = f ? f.id : (await RS("/segments", { name })).id;
}
function html(a) {
  return `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto"><h2>✈️ ${a.from} → ${a.to}</h2>
<p style="font-size:30px;margin:6px 0"><b>$${a.price}</b> <s style="color:#888;font-size:18px">$${a.usual}</s> <span style="color:#14b87a">−${a.pct}%</span></p>
<p>${a.dates} · ${a.transfers ? a.transfers + " stop" : "nonstop"}${a.airline ? " · " + a.airline : ""}</p>
<p style="color:#14b87a;font-size:13px">${a.verified ? "✓ Price re-checked live moments ago" : "Price from recent searches. It may have changed."}</p>
<p><a href="${a.link}" style="background:#ff6b4a;color:#fff;padding:12px 20px;border-radius:10px;text-decoration:none;font-weight:bold">View this fare</a></p>
<p style="color:#888;font-size:12px">Prices are cached and can change or sell out quickly. Skydrop earns a commission if you book through our link, at no extra cost to you.</p>
<p style="color:#888;font-size:12px"><a href="{{{RESEND_UNSUBSCRIBE_URL}}}">Unsubscribe</a></p></div>`;
}
async function tg(chat, text) {
  if (MOCK || !E.TELEGRAM_BOT_TOKEN || !chat) return;
  const r = await fetch(`https://api.telegram.org/bot${E.TELEGRAM_BOT_TOKEN}/sendMessage`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: chat, text }) });
  if (!r.ok) throw new Error("telegram " + r.status);
}
async function hook(deal) {   // signed webhook for YOUR notification software
  if (MOCK || !E.WEBHOOK_URL) return;
  const body = JSON.stringify({ id: crypto.randomUUID(), type: "deal.created", createdAt: new Date().toISOString(), deal });
  const sig = E.WEBHOOK_SECRET ? crypto.createHmac("sha256", E.WEBHOOK_SECRET).update(body).digest("hex") : "";
  const r = await fetch(E.WEBHOOK_URL, { method: "POST", headers: { "Content-Type": "application/json", "X-Skydrop-Signature": sig }, body });
  if (!r.ok) throw new Error("webhook " + r.status);
}
async function notify(a) {
  const subject = `✈️ ${a.from} → ${a.to} from $${a.price} (−${a.pct}%)`;
  const text = `${subject}\n${a.dates} · ${a.transfers ? a.transfers + " stop" : "nonstop"}${a.verified ? " · ✓ verified live" : " · cached price"}\nUsual ~$${a.usual}\n${a.link}`;
  console.log(DRY ? "[DRY] would alert:" : "ALERT:", subject, a.verified ? "(verified)" : "(unverified)");
  if (DRY) return;
  const deal = { origin: a.origin, destination: a.dest, originName: a.from, destinationName: a.to, price: a.price, currency: cfg.currency, usualPrice: a.usual, dropPercent: a.pct, dates: a.dates, transfers: a.transfers, airline: a.airline || null, link: a.link, verified: !!a.verified };
  const jobs = [() => tg(E.TELEGRAM_CHAT_ID, text), () => tg(E.TELEGRAM_CHANNEL_ID, text), () => hook(deal)];
  if (E.RESEND_API_KEY && E.ADMIN_EMAIL) jobs.push(() => RS("/emails", { from: cfg.from, to: [E.ADMIN_EMAIL], subject: "[Owner copy] " + subject, html: html(a).replace("{{{RESEND_UNSUBSCRIBE_URL}}}", cfg.siteUrl) }));
  if (E.RESEND_API_KEY && cfg.notifySubscribers) for (const sg of [a.origin, "ANYWHERE"]) jobs.push(async () => {
    const b = await RS("/broadcasts", { segment_id: await segId("airport:" + sg), from: cfg.from, subject, html: html(a), name: `Alert ${a.origin}-${a.dest} ${new Date().toISOString().slice(0, 10)}` });
    await RS(`/broadcasts/${b.id}/send`, {});
  });
  (await Promise.allSettled(jobs.map(f => f()))).forEach(r => r.status == "rejected" && console.warn("notify step failed:", r.reason.message));
}
// Live re-check of a candidate fare so subscribers never get a stale price (Duffel live search).
async function verify(a, x) {
  if (cfg.verify !== "duffel" || !E.DUFFEL_TOKEN) return { ok: null };
  try {
    const sl = [{ origin: a.origin, destination: a.dest, departure_date: x.departure_at.slice(0, 10) }];
    if (x.return_at) sl.push({ origin: a.dest, destination: a.origin, departure_date: x.return_at.slice(0, 10) });
    const r = await j("https://api.duffel.com/air/offer_requests?return_offers=true&supplier_timeout=10000", { method: "POST",
      headers: { Authorization: "Bearer " + E.DUFFEL_TOKEN, "Duffel-Version": "v2", "Content-Type": "application/json" },
      body: JSON.stringify({ data: { slices: sl, passengers: [{ type: "adult" }], cabin_class: "economy", max_connections: cfg.maxTransfers } }) });
    const live = (r.data?.offers || []).filter(f => (f.total_currency || "").toLowerCase() == cfg.currency).map(f => +f.total_amount).sort((p, q) => p - q)[0];
    if (!live) return { ok: false };
    return { ok: live <= a.price * (1 + cfg.verifyTolerancePct / 100), live: Math.round(live) };
  } catch (e) { console.warn("verify failed:", e.message); return { ok: null }; }
}

async function scan() {
await cities();
const found = [], alerts = [], now = Date.now();
for (const o of cfg.origins) {
  try {
    const r = await TP(`/aviasales/v3/prices_for_dates?origin=${o}&unique=true&sorting=price&one_way=false&limit=${cfg.perOrigin}&currency=${cfg.currency}`);
    for (const x of r.data || []) {
      if (!x.price || (x.transfers ?? 0) > cfg.maxTransfers || !x.departure_at) continue;
      const dest = x.destination, key = o + "-" + dest, st = state.routes[key] ||= { p: [] };
      const base = st.p.length >= cfg.minSamples ? med(st.p) : 0;
      const pct = base ? Math.round(100 - x.price / base * 100) : 0;
      const link = (x.link ? "https://www.aviasales.com" + x.link : `https://www.aviasales.com/search/${o}${dm(x.departure_at)}${dest}${x.return_at ? dm(x.return_at) : ""}1`) ; const link2 = link + (link.includes("?") ? "&" : "?") + "marker=" + (E.TRAVELPAYOUTS_MARKER || "");
      const a = { origin: o, dest, from: nm(o), to: nm(dest), price: Math.round(x.price), usual: Math.round(base), pct, transfers: x.transfers || 0, airline: x.airline, dates: fd(x.departure_at, x.return_at), link: link2 };
      if (base && pct >= 10) found.push({ ...a, intl: state.cities[o]?.c !== state.cities[dest]?.c });
      const last = state.sent[key];
      if (base && pct >= cfg.dropPercent && (!last || now - last.t > cfg.cooldownHours * 36e5 || a.price <= last.p * .9)) alerts.push({ a, key, x });
      st.p = [...st.p, a.price].slice(-30);
    }
  } catch (e) { console.warn("scan", o, e.message); }
  await sleep(MOCK ? 0 : 1200);
}
alerts.sort((x, y) => y.a.pct - x.a.pct);
let sent = 0;
for (const c of alerts) {
  if (sent >= cfg.maxAlertsPerRun) break;
  const v = await verify(c.a, c.x), live = cfg.verify === "duffel" && E.DUFFEL_TOKEN;
  if (live && v.ok !== true) { console.log("skip (not confirmed by live search):", c.key, JSON.stringify(v)); continue; }
  if (v.live) { c.a.price = v.live; c.a.pct = Math.round(100 - v.live / c.a.usual * 100); if (c.a.pct < cfg.dropPercent) { console.log("skip (live price too high):", c.key); continue; } }
  c.a.verified = v.ok === true;
  await notify(c.a); sent++;
  if (!DRY) state.sent[c.key] = { t: now, p: c.a.price };
}
found.sort((x, y) => y.pct - x.pct);
const deals = found.slice(0, 12).map(x => ({ t: x.intl ? "International" : "Domestic", n: x.to + " deal", r: x.from + " → " + x.to, p: x.price, o: x.usual, d: x.dates, link: x.link }));
fs.writeFileSync(DF, JSON.stringify({ updated: new Date().toISOString(), deals }, null, 1));
if (!DRY) fs.writeFileSync(SF, JSON.stringify(state));
console.log(`Scanned ${cfg.origins.length} origins · ${found.length} drops ≥10% · ${alerts.length} alert candidates · ${deals.length} deals written`);

}
if (process.argv.includes("--loop")) {   // always-on mode: scan every INTERVAL_SEC (default 120)
  for (;;) { try { await scan(); } catch (e) { console.error("scan error:", e.message); } await sleep((+E.INTERVAL_SEC || 120) * 1000); }
} else await scan();
