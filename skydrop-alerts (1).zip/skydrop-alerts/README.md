# Skydrop alerts v2: fast, verified cheap-flight alerts

Scan → detect a real drop → **re-check the price live** → notify you and your subscribers within seconds.

## How "instant" really works
No flight API pushes "this fare just dropped" events. Every provider has to be polled, so your delay =
**poll interval + how fresh the provider's data is**. This project minimises both:

| Stage | Source | Freshness | Cost |
|---|---|---|---|
| 1. Discovery (broad, every 2–10 min) | Aviasales Data API via Travelpayouts | Cached from user searches, hours to ~2 days old | Free (partner account, earns affiliate commission) |
| 2. Verification (only candidates) | Duffel live search (airline NDC/GDS/LCC) | Live | Self-serve; check their pricing/search fees |
| 3. Notify (parallel) | Telegram (you + public channel), signed webhook, email | Seconds | Free / your plan |

Only fares **confirmed by the live search** (within `verifyTolerancePct`) are sent, and the alert carries the live price,
so subscribers are never sent to a fare that is already gone.

## Providers: what's usable
- **Travelpayouts / Aviasales Data API:** free, self-serve, built for sites like yours. Cached, so use it for discovery only.
- **Duffel:** self-serve, live airline content, sandbox token. It is built for selling tickets; heavy search with no bookings may be limited, so confirm their search fee/ratio policy before scaling. Verify only candidates (a few calls per hour).
- **Skyscanner API:** partner-only (apply through their affiliates team); no open signup. Do not scrape it.
- **Kiwi Tequila:** closed to new self-signups. **Amadeus Self-Service:** shut down 17 July 2026.
- **flight-fare.com, Google Flights:** no public API; scraping breaks their terms.
- Later upgrade: Skyscanner partner access or Amadeus Enterprise if you outgrow the above.

## Deploy for real-time (recommended): always-on worker
GitHub Actions cron (included, every 10 min) is a backup. It can run late and tops out at 5-minute spacing.
For 1–3 minute freshness run the worker continuously on Fly.io / Railway / Render / any VPS:
`docker build -t skydrop . && docker run -d -v skydrop-data:/app/data --env-file .env skydrop`
(`INTERVAL_SEC=120` by default; keep a persistent volume for `data/`.) Mind the API rate limits.

## Env vars
`TRAVELPAYOUTS_TOKEN`, `TRAVELPAYOUTS_MARKER`, `DUFFEL_TOKEN` (optional but recommended), `RESEND_API_KEY`, `ADMIN_EMAIL`,
`TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID` (instant phone push to you), `TELEGRAM_CHANNEL_ID` (public channel = free instant alerts for subscribers),
`WEBHOOK_URL` + `WEBHOOK_SECRET` (your future notification software), `INTERVAL_SEC`.
Telegram: create a bot with @BotFather, message it once, then read your chat id from `https://api.telegram.org/bot<TOKEN>/getUpdates`.

## Webhook for your own software
`POST WEBHOOK_URL`, header `X-Skydrop-Signature` = hex HMAC-SHA256 of the raw body using `WEBHOOK_SECRET`. Body:
```json
{"id":"uuid","type":"deal.created","createdAt":"ISO","deal":{"origin":"JFK","destination":"LIS","originName":"New York",
 "destinationName":"Lisbon","price":364,"currency":"usd","usualPrice":714,"dropPercent":49,"dates":"Dec 3–10",
 "transfers":0,"airline":"TP","link":"https://www.aviasales.com/search/...?marker=...","verified":true}}
```
Verify the signature, respond 2xx fast, and de-duplicate on `id`.

## Setup & first run
1. Get Travelpayouts token + marker (free). Optional: Duffel token, Telegram bot.
2. Verify a sending domain in Resend (needed to email subscribers) and set `from`/`siteUrl` in `config.json`.
3. `npm run dry` with your token to see real output without sending. Fix any field names it complains about (not tested live).
4. Deploy the worker (Docker host or GitHub Actions) and the site (Vercel, output dir `public`).

## Tuning (config.json)
`origins`, `dropPercent` (35), `minSamples` (4 scans before alerts start), `cooldownHours` (72), `maxAlertsPerRun`, `verify` ("duffel" or "none"), `verifyTolerancePct` (15).

## Compliance
Only message people who opted in; keep unsubscribe; use double opt-in; disclose affiliate links (in email footer);
check GDPR / CAN-SPAM / Telegram channel rules. Prices can change or sell out, so keep the wording honest.
