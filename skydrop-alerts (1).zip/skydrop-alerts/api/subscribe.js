// Vercel serverless function: POST {email, airport} -> adds contact to the Resend segment "airport:XXX".
const RS = (p, body, method = "POST") => fetch("https://api.resend.com" + p, { method,
  headers: { Authorization: "Bearer " + process.env.RESEND_API_KEY, "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const { email, airport, website } = req.body || {};
  if (website) return res.status(200).json({ ok: true });            // honeypot
  if (!/^\S+@\S+\.\S+$/.test(email || "")) return res.status(400).json({ error: "Invalid email" });
  const code = ((airport || "").match(/\(([A-Z]{3})\)/) || [])[1] || "ANYWHERE", name = "airport:" + code;
  try {
    const list = await (await RS("/segments", null, "GET")).json();
    let id = (list.data || []).find(s => s.name === name)?.id;
    if (!id) id = (await (await RS("/segments", { name })).json()).id;
    await RS("/contacts", { email });                                  // ignore "already exists"
    const r = await RS(`/contacts/${encodeURIComponent(email)}/segments/${id}`);
    return res.status(r.ok ? 200 : 502).json({ ok: r.ok });
  } catch (e) { return res.status(500).json({ error: "Could not subscribe" }); }
}
